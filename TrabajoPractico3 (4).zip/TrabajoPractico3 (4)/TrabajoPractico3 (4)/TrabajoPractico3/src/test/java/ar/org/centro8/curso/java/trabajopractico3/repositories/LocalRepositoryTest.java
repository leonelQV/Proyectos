package ar.org.centro8.curso.java.trabajopractico3.repositories;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Local;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_LocalRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.LocalRepository;

public class LocalRepositoryTest {

    I_LocalRepository localRepository = new LocalRepository(Connector.getConnection());

    @Test
    void testSave() {
        Local local1 = new Local("ooo", "ooo", "Caballito");
        Local local2 = new Local("ooo", "ooo", "Caballito");
        localRepository.save(local1);
        localRepository.save(local2);

        assertEquals(local1.getIdLocal() > 0, true);
        assertEquals(local1.getIdLocal(), local2.getIdLocal() - 1);
    }

    @Test
    void testGetAll() {
        assertEquals(localRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = localRepository.getAll().size();
        localRepository.remove(localRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = localRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = localRepository.getAll().size();
        Local local = localRepository.getAll().get(cantidad - 1);
        local.setTelefono("ooo");
        local.setMail("ooo");
        local.setSucursal("Caballito");
        localRepository.update(local);
        Local local2 = localRepository.getAll().get(cantidad - 1);

        assertEquals(local.getTelefono(), local2.getTelefono());
        assertEquals(local.getMail(), local2.getMail());
        assertEquals(local.getSucursal(), local2.getSucursal());

    }
}
