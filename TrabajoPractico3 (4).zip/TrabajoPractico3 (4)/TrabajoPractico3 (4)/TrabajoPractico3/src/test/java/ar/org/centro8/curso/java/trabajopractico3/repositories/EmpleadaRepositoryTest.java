package ar.org.centro8.curso.java.trabajopractico3.repositories;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import ar.org.centro8.curso.java.trabajopractico3.connector.Connector;
import ar.org.centro8.curso.java.trabajopractico3.entities.Empleada;
import ar.org.centro8.curso.java.trabajopractico3.enums.TipoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.enums.TurnoTrabajo;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_EmpleadaRepository;
import ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc.EmpleadaRepository;

public class EmpleadaRepositoryTest {

    I_EmpleadaRepository empleadaRepository = new EmpleadaRepository(Connector.getConnection());

    @Test
    void testSave() {
        Empleada empleada1 = new Empleada("ooo", TipoTrabajo.EspecialistaEnPestañasCejas, TurnoTrabajo.Mañana);
        Empleada empleada2 = new Empleada("ooo", TipoTrabajo.EspecialistaEnPestañasCejas, TurnoTrabajo.Mañana);
        empleadaRepository.save(empleada1);
        empleadaRepository.save(empleada2);

        assertEquals(empleada1.getIdEmpleada() > 0, true);
        assertEquals(empleada1.getIdEmpleada(), empleada2.getIdEmpleada() - 1);
    }

    @Test
    void testGetAll() {
        assertEquals(empleadaRepository.getAll().size() >= 2, true);
    }

    @Test
    void testRemove() {
        int cantidadInicial = empleadaRepository.getAll().size();
        empleadaRepository.remove(empleadaRepository.getAll().get(cantidadInicial - 1));
        int cantidadFinal = empleadaRepository.getAll().size();
        assertEquals(cantidadInicial, cantidadFinal + 1);
    }

    @Test
    void testUpdate() {
        int cantidad = empleadaRepository.getAll().size();
        Empleada empleada = empleadaRepository.getAll().get(cantidad - 1);
        empleada.setNombreApellido("ooo");
        empleada.setTipoTrabajo(TipoTrabajo.EspecialistaEnPestañasCejas);
        empleada.setTurnoTrabajo(TurnoTrabajo.Mañana);
        empleadaRepository.update(empleada);
        Empleada empleada2 = empleadaRepository.getAll().get(cantidad - 1);

        assertEquals(empleada.getNombreApellido(), empleada2.getNombreApellido());
        assertEquals(empleada.getTipoTrabajo(), empleada2.getTipoTrabajo());
        assertEquals(empleada.getTurnoTrabajo(), empleada2.getTurnoTrabajo());

    }
}
