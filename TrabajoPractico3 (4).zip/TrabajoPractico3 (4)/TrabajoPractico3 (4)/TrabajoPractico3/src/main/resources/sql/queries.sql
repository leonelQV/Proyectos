
  -- Queries
  -- Mostrar todos los turnos del dia 12/10/2022
  select * 
  from   turnos
  where  fecha='12/10/22';
  -- Mostrar todas las empleadas que trabajan en el sucursal de Morón
  select    e.nombreApellido as empleada,
            e.tipotrabajo  as 'Tipo de trabajo',
            l.sucursal as local
  from       empleadas e
  inner join turnos t on e.idEmpleada = t.idEmpleada
  inner join locales l on l.idlocal = t.idlocal
  where      t.idlocal = 2;

  -- Todas las clientas que se atienda el dia 16/10/2022
  select     c.nombreApellido as Clienta
  from       clientas c
  inner join turnos t on c.idClienta = t.idClienta
  where      fecha = '16/10/22';

  -- Todas las clientas que se hacen uñas acrilicas
  select     c.nombreApellido as clienta,
             l.sucursal as local
  from       clientas c
  inner join turnos t on c.idClienta = t.idClienta
  inner join locales l on l.idlocal = t.idlocal
  where      idTratamiento = 3;

  -- Todos los tratamiento que se hacen el dia 12/10/22
  select     tipoTratamiento as Tratamiento
  from       tratamientos r
  inner join turnos t on r.idtratamiento = t.idtratamiento
  where      fecha = '12/10/22';

  -- Todas las empleadas que trabajan en dia 16/10/22
  select     nombreApellido as empleada
  from       empleadas e
  inner join turnos t on e.idEmpleada = t.idEmpleada
  where      fecha = '16/10/22';
