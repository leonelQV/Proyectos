package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public interface I_TurnoRepository {
    void save(Turno turno);

    void remove(Turno turno);

    void update(Turno turno);

    default Turno getByIdTurno(int idTurno) {
        return getAll()
                .stream()
                .filter(t -> t.getIdTurno() == idTurno)
                .findAny()
                .orElse(new Turno());
    }

    List<Turno> getAll();

    // fecha
    default List<Turno> getLikeFecha(String fecha) {
        if (fecha == null)
            return new ArrayList();
        return getAll()
                .stream() // from
                .filter(t -> t.getFecha()
                        .toLowerCase()
                        .contains(fecha.toLowerCase())) // where
                .toList();
    }

    // hora
    default List<Turno> getLikeHora(Hora hora) {
        if (hora == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(t -> t.getHora() == hora)
                .toList();
    }
}
