package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import ar.org.centro8.curso.java.trabajopractico3.entities.Clienta;
import java.util.ArrayList;
import java.util.List;

public interface I_ClientaRepository {
  void save(Clienta clienta); // insert

  void remove(Clienta clienta); // delete

  void update(Clienta clienta); // update

  default Clienta getByIdClienta(int idClienta) {
    return getAll()
        .stream()
        .filter(c -> c.getIdClienta() == idClienta)
        .findAny()
        .orElse(new Clienta());
  }

  List<Clienta> getAll();

  // nombre
  default List<Clienta>getLikeNombreApellido(String nombreApellido) {
    if (nombreApellido == null)
      return new ArrayList();
    return getAll()
        .stream() // from
        .filter(c -> c.getNombreApellido() != null) // where
        .filter(c -> c // where
            .getNombreApellido()
            .toLowerCase()
            .contains(nombreApellido.toLowerCase()))// otra subcadena
        .toList();
  }

  // mail
  default List<Clienta>getLikeMail(String mail) {
    if (mail == null)
      return new ArrayList();
    return getAll()
        .stream()
        .filter(c -> c
            .getMail()
            .toLowerCase()
            .contains(mail.toLowerCase()))
        .toList();
  }

}
