package ar.org.centro8.curso.java.trabajopractico3.enums;

public enum TipoTrabajo {
    Manicura, 
    Esteticista, 
    EspecialistaEnPestañasCejas;

    public Object getIdEmpleada() {
        return null;
    }

}
