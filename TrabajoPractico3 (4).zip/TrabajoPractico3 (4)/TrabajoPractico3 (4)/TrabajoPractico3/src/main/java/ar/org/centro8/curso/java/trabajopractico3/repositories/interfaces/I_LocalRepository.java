package ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Local;

public interface I_LocalRepository {
  void save(Local local);

  void remove(Local local);

  void update(Local local);

  default Local getByIdLocal(int idLocal) {
    return getAll()
        .stream()
        .filter(l -> l.getIdLocal() == idLocal)
        .findAny()
        .orElse(new Local());

  }

  List<Local> getAll();

  // sucursal
  default List<Local> getLikeSucursal(String sucursal) {
    if (sucursal == null)
      return new ArrayList();
    return getAll()
        .stream() // from
        .filter(l -> l.getSucursal()
        .toLowerCase()
        .contains(sucursal.toLowerCase())) // where
        .toList();
  }

  // mail
  default List<Local> getLikeMail(String mail) {
    if (mail == null)
      return new ArrayList();
    return getAll()
        .stream()
        .filter(c -> c
            .getMail()
            .toLowerCase()
            .contains(mail.toLowerCase()))
        .toList();
  }
}
