package ar.org.centro8.curso.java.trabajopractico3.entities;


public class Local {

    private int idLocal;
    private String telefono;
    private String mail;
    private String sucursal;

    public Local() {
    }

    public Local(String telefono, String mail, String sucursal) {
        this.telefono = telefono;
        this.mail = mail;
        this.sucursal = sucursal;
    }

    public Local(int idLocal, String telefono, String mail, String sucursal) {
        this.idLocal = idLocal;
        this.telefono = telefono;
        this.mail = mail;
        this.sucursal = sucursal;
    }

    @Override
    public String toString() {
        return "Empleada [idLocal=" + idLocal + ", telefono=" + telefono + ", mail=" + mail + ", sucursal=" + sucursal
                + "]";
    }

    public int getIdLocal() {
        return idLocal;
    }

    public void setIdLocal(int idLocal) {
        this.idLocal = idLocal;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail;
    }

    public String getSucursal() {
        return sucursal;
    }

    public void setSucursal(String sucursal) {
        this.sucursal = sucursal;
    }

}
