package ar.org.centro8.curso.java.trabajopractico3.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.trabajopractico3.entities.Turno;
import ar.org.centro8.curso.java.trabajopractico3.enums.Hora;
import ar.org.centro8.curso.java.trabajopractico3.repositories.interfaces.I_TurnoRepository;

public class TurnoRepository implements I_TurnoRepository {
    private Connection conn;

    public TurnoRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Turno> getAll() {
        List<Turno> list = new ArrayList<>();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from turnos")) {
            while (rs.next()) {
                list.add(new Turno(rs.getInt("idTurno"),
                 rs.getString("fecha"),
                  Hora.valueOf(rs.getString("hora")),
                  rs.getDouble("precio"), 
                  rs.getInt("idEmpleada"), 
                  rs.getInt("idLocal"), 
                  rs.getInt("idClienta"), 
                  rs.getInt("idTratamiento")));
            }


            
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void remove(Turno turno) {
        if (turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from turnos where idTurno=?",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, turno.getIdTurno());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void save(Turno turno) {
        if (turno == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into turnos (fecha, hora, precio, idEmpleada, idLocal, idClienta, idTratamiento) values (?,?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setString(1,  turno.getFecha());
            ps.setString(2, turno.getHora().toString());
            ps.setDouble(3, turno.getPrecio());
            ps.setInt(4, turno.getIdEmpleada());
            ps.setInt(5, turno.getIdLocal());
            ps.setInt(6, turno.getIdClienta());
            ps.setInt(7, turno.getIdTratamiento());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                turno.setIdTurno(rs.getInt(1));

        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Turno turno) {
        if (turno == null) // fecha, hora, precio, idEmpleada, idLocal, idTratamiento
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update turnos set fecha=?, hora=?, precio=?, idEmpleada=?, idLocal=?, idClienta=?, idTratamiento=? where idTurno=?")) {
            ps.setString(1,   turno.getFecha());
            ps.setString(2, turno.getHora().toString());
            ps.setDouble(3, turno.getPrecio());
            ps.setInt(4, turno.getIdEmpleada());
            ps.setInt(5, turno.getIdLocal());
            ps.setInt(6, turno.getIdClienta());
            ps.setInt(7, turno.getIdTratamiento());
            ps.setInt(8, turno.getIdTurno());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
