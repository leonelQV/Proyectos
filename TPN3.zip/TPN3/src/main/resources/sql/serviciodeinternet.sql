drop database if exists serviciodeinternet;
create database serviciodeinternet;
use serviciodeinternet;

drop database if exists categorias;

CREATE TABLE categorias (
id_categorias INT NOT NULL,
packs ENUM('p1', 'p2', 'p3', 'p4', 'p5', 'p6') NOT NULL,
precios FLOAT NULL,
gigas ENUM('GB1', 'GB2', 'GB3', 'GB4') NULL,
dias ENUM('DIAX1', 'DIAX2', 'DIAX3', 'DIAX4') NULL,
PRIMARY KEY (`id_categorias`)
);

drop database if exists clientes;

CREATE TABLE IF NOT EXISTS clientes (
  id_clientes INT NOT NULL,
  nombre VARCHAR(25) NOT NULL,
  apellido VARCHAR(25) NOT NULL,
  dni VARCHAR(25) NULL DEFAULT NULL,
  PRIMARY KEY (id_clientes),
  id_categorias INT NOT NULL
  )
  ;

drop database if exists empleados;

CREATE TABLE IF NOT EXISTS empleados (
  id_empleados INT NOT NULL,
  nombre VARCHAR(25) NOT NULL,
  apellido VARCHAR(25) NOT NULL,
  sueldo VARCHAR(25) NULL DEFAULT NULL,
  PRIMARY KEY (id_empleados),
  id_categorias INT NOT NULL
  )
  ;
  
drop database if exists ventas;

CREATE TABLE ventas(
id_ventas INT NOT NULL,
fechas VARCHAR(20) NOT NULL,
PRIMARY KEY (id_ventas),
id_categorias INT NOT NULL,
id_clientes INT NOT NULL,
id_empleados INT NOT NULL,
 
CONSTRAINT id_clientes FOREIGN KEY (id_ventas) REFERENCES clientes (id_clientes)
ON DELETE NO ACTION 
ON UPDATE NO ACTION,

CONSTRAINT id_empleados FOREIGN KEY (id_ventas) REFERENCES empleados (id_empleados)
ON DELETE NO ACTION 
ON UPDATE NO ACTION,

CONSTRAINT id_categorias FOREIGN KEY (id_ventas) REFERENCES categorias (id_categorias)
ON DELETE NO ACTION
ON UPDATE NO ACTION
);





  
  












