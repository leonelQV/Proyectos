use serviciodeinternet;

select * from categorias;

insert into categorias values ('1','p1','100', 'GB1', 'DIAX1');
insert into categorias values ('2','p2','200', 'GB2', 'DIAX2');
insert into categorias values ('3','p3','300', 'GB3', 'DIAX3');
insert into categorias values ('4','p4','400', 'GB4', 'DIAX4');

select * from clientes;

insert into clientes values	(1,'Luis','Alvarez','43902859',1);
insert into clientes values	(2,'Lorena','Zarate','43421547',2);
insert into clientes values	(3,'Mauro','Sanchez','43982345',3);
insert into clientes values	(4,'Maria','Cruz','43802314',4);

select* from empleados;

insert into empleados values(1,'Ernesto', 'Perez', '$15000',1);
insert into empleados values(2,'Fabricio', 'Morales', '$18000',2);
insert into empleados values(3,'Enrique', 'Rivas', '$20000',3);
insert into empleados values(4,'Juan', 'Polman', '$30000',4);

select*from ventas;

insert into ventas values ('1', '15/03/2022',1,1,1);
insert into ventas values ('2', '18/04/2022',2,2,2);
insert into ventas values ('3', '10/05/2022',3,3,3);
insert into ventas values ('4', '30/06/2022',4,4,4);
