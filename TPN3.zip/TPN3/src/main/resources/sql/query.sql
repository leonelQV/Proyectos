use serviciodeinternet;

SELECT * FROM clientes;
SELECT * FROM ventas;
SELECT * FROM categorias;
SELECT * FROM empleados;

/*
ejemplos de ayuda
  
select c.nombre, ca.packs,ca.dias,ca.gigas,ca.precios
from clientes c, categorias ca
where  c.id_categorias = ca.id_categorias;

select c.nombre, ca.packs, e.nombre, e.apellido, v.fechas ventas
from clientes c, categorias ca, empleados e, ventas v
where  c.id_categorias = ca.id_categorias
and e.id_empleados = v.id_empleados;
*/

-- empleado con mayor sueldo

select nombre, apellido, sueldo
from empleados  
where sueldo >= '$30000';

-- el fechas de packs vendidos

select ca.packs, v.fechas
from categorias ca, ventas v
where ca.id_categorias = v.id_categorias;

-- se requiere las ventas que hicieron los empleados

select e.nombre, e.apellido, v.fechas
from empleados e, ventas v  
where e.id_empleados = v.id_empleados;

-- el cliente Maria compra el pack 4 con su fecha indicada 30/06/2022

select c.nombre, ca.packs, v.fechas
from clientes c, categorias ca, ventas v
where c.id_categorias = ca.id_categorias 
and v.id_categorias = ca.id_categorias
and c.nombre = 'Maria' 
and ca.packs = '4'
and v.fechas = '30/06/2022';

-- el empleado Enrique vende el pack 3 el dia de la fecha indicada '10/05/2022' 

select e.nombre empleado,
c.packs, c.precios, c.gigas, c.dias,
v.fechas fecha
from categorias c, empleados e, ventas v 
where e.id_categorias = c.id_categorias
and v.id_categorias = c.id_categorias
and e.nombre = 'Enrique'
;

-- el cliente Maria compra el pack 4

select c.nombre cliente, ca.packs
from clientes c, categorias ca
where c.id_categorias = ca.id_categorias
and c.nombre='Maria'
;
