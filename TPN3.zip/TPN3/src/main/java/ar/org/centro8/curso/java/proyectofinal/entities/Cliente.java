package ar.org.centro8.curso.java.proyectofinal.entities;

public class Cliente {

    private int id_clientes;
    private String nombre;
    private String apellido;
    private String dni;
    private int id_categorias;

    public Cliente() {
    }

    public Cliente(String nombre, String apellido, String dni, int id_categorias) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.id_categorias = id_categorias;
    }

    public Cliente(int id_clientes, String nombre, String apellido, String dni, int id_categorias) {
        this.id_clientes = id_clientes;
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.id_categorias = id_categorias;
    }

    @Override
    public String toString() {
        return "Cliente [id_clientes=" + id_clientes + ", nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni
                + ", id_categorias=" + id_categorias + "]";
    }

    public int getid_clientes() {
        return id_clientes;
    }

    public void setid_clientes(int id_clientes) {
        this.id_clientes = id_clientes;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getid_categorias() {
        return id_categorias;
    }

    public void setid_categorias(int id_categorias) {
        this.id_categorias = id_categorias;
    }

    public int getid_ventas() {
        return 0;
    }

}
