package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Categoria;
import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Giga;
import ar.org.centro8.curso.java.proyectofinal.enums.Pack;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_CategoriaRepository;

public class CategoriaRepository implements I_CategoriaRepository {
    private Connection conn;

    @Override
    public List<Categoria> getAll() {
        List<Categoria> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from categorias")) {
            while (rs.next()) {
                list.add(new Categoria(
                        rs.getInt("id_categorias"),
                        Dia.valueOf(rs.getString("dias")),
                        rs.getInt("precios"),
                        Giga.valueOf(rs.getString("gigas")),
                        Pack.valueOf(rs.getString("packs"))));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Categoria categorias) {
        if (categorias == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into categorias (id_categorias,dias,precio,gigas,packs) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, categorias.getid_categorias());
            ps.setString(2, categorias.getDia().toString());
            ps.setInt(3, categorias.getPrecios());
            ps.setString(4, categorias.getGigas().toString());
            ps.setString(5, categorias.getPacks().toString());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                categorias.setid_categorias(((rs.getInt(1))));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Categoria categorias) {
        if (categorias == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from categorias where id_categorias=?")) {
            ps.setInt(1, categorias.getid_categorias());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Categoria categorias) {
        if (categorias == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update clientes set dia=?, precio=?, gigas=?, packs=? where id_categorias=?")) {
            ps.setString(1, categorias.getDia().toString());
            ps.setInt(2, categorias.getPrecios());
            ps.setString(3, categorias.getGigas().toString());
            ps.setString(4, categorias.getPacks().toString());
            ps.setInt(5, categorias.getid_categorias());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}