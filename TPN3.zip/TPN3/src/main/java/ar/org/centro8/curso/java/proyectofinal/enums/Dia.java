package ar.org.centro8.curso.java.proyectofinal.enums;

public enum Dia {
   DIAX1,
   DIAX2,
   DIAX3,
   DIAX4,
}
