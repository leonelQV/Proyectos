package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_EmpleadoRepository;

public class EmpleadoRepository implements I_EmpleadoRepository {
    private Connection conn;

    @Override
    public List<Empleado> getAll() {
        List<Empleado> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from empleados")) {
            while (rs.next()) {
                list.add(new Empleado(
                        rs.getInt("id_Empleado"),
                        rs.getString("nombre"),
                        rs.getString("apellido"),
                        rs.getString("sueldo"),
                        rs.getInt("id_categorias")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Empleado empleados) {
        if (empleados == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into empleados (id_empleados,nombre,apellido,sueldo,id_categorias,id_ventas) values (?,?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, empleados.getid_empleados());
            ps.setString(2, empleados.getNombre());
            ps.setString(3, empleados.getApellido());
            ps.setString(4, empleados.getSueldo());
            ps.setInt(5, empleados.getid_categorias());
            ps.setInt(6, empleados.getid_ventas());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                empleados.setid_empleados((rs.getInt(1)));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Empleado empleados) {
        if (empleados == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from empleados where id_empleados?")) {
            ps.setInt(1, empleados.getid_empleados());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Empleado empleados) {
        if (empleados == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update empleados set nombre=?, apellido=?, sueldo=?, id_categorias=? where id_empleados=?")) {
            ps.setString(1, empleados.getNombre());
            ps.setString(2, empleados.getApellido());
            ps.setString(3, empleados.getSueldo());
            ps.setInt(4, empleados.getid_categorias());
            ps.setInt(5, empleados.getid_ventas());
            ps.setInt(5, empleados.getid_empleados());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
