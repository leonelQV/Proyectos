package ar.org.centro8.curso.java.proyectofinal.entities;

import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Giga;
import ar.org.centro8.curso.java.proyectofinal.enums.Pack;

public class Categoria {

    private int id_categorias;
    private Dia dia;
    private int precios;
    private Giga gigas;
    private Pack packs;

    public Categoria() {
    }

    public Categoria(Dia dia, int precios, Giga gigas, Pack packs) {
        this.dia = dia;
        this.precios = precios;
        this.gigas = gigas;
        this.packs = packs;
    }

    public Categoria(int id_categorias, Dia dia, int precios, Giga gigas, Pack packs) {
        this.id_categorias = id_categorias;
        this.dia = dia;
        this.precios = precios;
        this.gigas = gigas;
        this.packs = packs;
    }

    @Override
    public String toString() {
        return "Categorias [id_categorias=" + id_categorias + ", dia=" + dia + ", precios=" + precios + ", gigas="
                + gigas + ", packs=" + packs + "]";
    }

    public int getid_categorias() {
        return id_categorias;
    }

    public void setid_categorias(int id_categorias) {
        this.id_categorias = id_categorias;
    }

    public Dia getDia() {
        return dia;
    }

    public void setDia(Dia dia) {
        this.dia = dia;
    }

    public int getPrecios() {
        return precios;
    }

    public void setPrecios(int precios) {
        this.precios = precios;
    }

    public Giga getGigas() {
        return gigas;
    }

    public void setGigas(Giga gigas) {
        this.gigas = gigas;
    }

    public Pack getPacks() {
        return packs;
    }

    public void setPacks(Pack packs) {
        this.packs = packs;
    }

    public int getid_cliente() {
        return 0;
    }

    public int getid_empleados() {
        return 0;
    }

}
