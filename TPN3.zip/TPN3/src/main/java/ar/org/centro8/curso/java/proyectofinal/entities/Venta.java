package ar.org.centro8.curso.java.proyectofinal.entities;

public class Venta {

    private int id_ventas;
    private String fechas;
    private int id_categorias;
    private int id_cliente;
    private int id_empleados;

    public Venta() {
    }

    public Venta(String fechas, int id_categorias, int id_cliente, int id_empleados) {
        this.fechas = fechas;
        this.id_categorias = id_categorias;
        this.id_cliente = id_cliente;
        this.id_empleados = id_empleados;
    }

    public Venta(int id_ventas, String fechas, int id_categorias, int id_cliente, int id_empleados) {
        this.id_ventas = id_ventas;
        this.fechas = fechas;
        this.id_categorias = id_categorias;
        this.id_cliente = id_cliente;
        this.id_empleados = id_empleados;
    }

    @Override
    public String toString() {
        return "Ventas [id_ventas=" + id_ventas + ", fechas=" + fechas + ", id_categorias=" + id_categorias
                + ", id_cliente=" + id_cliente + ", id_empleados=" + id_empleados + "]";
    }

    public int getId_ventas() {
        return id_ventas;
    }

    public void setId_ventas(int id_ventas) {
        this.id_ventas = id_ventas;
    }

    public String getFechas() {
        return fechas;
    }

    public void setFechas(String fechas) {
        this.fechas = fechas;
    }

    public int getId_categorias() {
        return id_categorias;
    }

    public void setId_categorias(int id_categorias) {
        this.id_categorias = id_categorias;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_empleados() {
        return id_empleados;
    }

    public void setId_empleados(int id_empleados) {
        this.id_empleados = id_empleados;
    }

}
