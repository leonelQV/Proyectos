package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Categoria;
import ar.org.centro8.curso.java.proyectofinal.entities.Cliente;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Giga;
import ar.org.centro8.curso.java.proyectofinal.enums.Pack;

public interface I_CategoriaRepository {

    void save(Categoria categorias);

    void remove(Categoria categorias);

    void update(Categoria categorias);

    List<Categoria> getAll();

    default Stream<Categoria> getStream() {
        return getAll().stream();
    }

    default Categoria getbyid_Categoria(int id_categorias) {
        return getAll()
                .stream()
                .filter(a -> a.getid_categorias() == id_categorias)
                .findAny()
                .orElse(new Categoria());
    }

    default List<Categoria> getPrecio(int precios) {
        if (precios == 0)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getPrecios() != 0)
                .toList();
    }

    default List<Categoria> getDia(Dia dias) {
        if (dias == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getDia() != null)
                .toList();
    }

    default List<Categoria> getGiga(Giga gigas) {
        if (gigas == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getGigas() != null)
                .toList();
    }

    default List<Categoria> getPack(Pack packs) {
        if (packs == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getPacks() != null)
                .toList();
    }

    default List<Categoria> getByVenta(Venta ventas) {
        if (ventas == null)
            return new ArrayList<Categoria>();
        return getStream()
                .filter(a -> a.getid_categorias() == ventas.getid_ventas())
                .collect(Collectors.toList());
    }

    default List<Categoria> getByCliente(Cliente clientes) {
        if (clientes == null)
            return new ArrayList<Categoria>();
        return getStream()
                .filter(a -> a.getid_cliente() == clientes.getid_clientes())
                .collect(Collectors.toList());
    }
    default List<Categoria> getBySucursal(Empleado empledados) {
        if (empledados == null)
            return new ArrayList<Categoria>();
        return getStream()
                .filter(a -> a.getid_empleados() == empledados.getid_empleados())
                .collect(Collectors.toList());
    }

}
