package ar.org.centro8.curso.java.proyectofinal.enums;

public enum Giga {
   GB1,
   GB2,
   GB3,
   GB4
}
