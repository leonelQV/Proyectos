package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Categoria;
import ar.org.centro8.curso.java.proyectofinal.entities.Cliente;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;

public interface I_ClienteRepository {

    void save(Cliente clientes);

    void remove(Cliente clientes);

    void update(Cliente clientes);

    List<Cliente> getAll();

    default Stream<Cliente> getStream() {
        return getAll().stream();
    }

    default Cliente getbyid_Cliente(int id_clientes) {
        return getAll()
                .stream()
                .filter(a -> a.getId_clientes() == id_clientes)
                .findAny()
                .orElse(new Cliente());
    }

    default List<Cliente> getLikeNombre(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getNombre() != null)
                .filter(a -> a
                        .getNombre()
                        .toLowerCase()
                        .contains(nombre.toLowerCase()))
                .toList();
    }

    default List<Cliente> getLikeApellido(String apellido) {
        if (apellido == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getApellido() != null)
                .filter(a -> a
                        .getApellido()
                        .toLowerCase()
                        .contains(apellido.toLowerCase()))
                .toList();
    }

    default List<Cliente> getByCategoria(Categoria categorias) {
        if (categorias == null)
            return new ArrayList<Cliente>();
        return getStream()
                .filter(a -> a.getId_categorias() == Categoria.getId_categorias())
                .collect(Collectors.toList());
    }

    default List<Cliente> getByVenta(Venta ventas) {
        if (ventas == null)
            return new ArrayList<Cliente>();
        return getStream()
                .filter(a -> a.getId_categorias() == ventas.getId_ventas())
                .collect(Collectors.toList());
    }

}
