package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;
import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Categoria;
import ar.org.centro8.curso.java.proyectofinal.entities.Cliente;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.enums.Dia;
import ar.org.centro8.curso.java.proyectofinal.enums.Giga;
import ar.org.centro8.curso.java.proyectofinal.enums.Pack;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_CategoriaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_ClienteRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_EmpleadoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_VentaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.CategoriaRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.ClienteRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.EmpleadoRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.VentaRepository;

public class TestRepository {
    public static void main(String[] args) {
        Connection conn=Connector.getConnection();

        //clientes

        I_ClienteRepository clienteRepository=new ClienteRepository(conn);
        Cliente cliente = new Cliente("Carla","Muños","43923458",1);
        clienteRepository.save(cliente);
        System.out.println(cliente);

        clienteRepository.remove(clienteRepository.getbyid(1));

        cliente = clienteRepository.getbyid(2);
        if(cliente != null && cliente.getid_clientes() != 2){
            cliente.setNombre("Luis");
            cliente.setApellido("Alvarez");
            clienteRepository.update(cliente);
        }

        System.out.println("**************************************");
        clienteRepository.getAll().forEach(System.out::println);

        System.out.println("**************************************");
        clienteRepository
            .getLikeNombre("is")
            .forEach(System.out::println);
        System.out.println("**************************************");
        clienteRepository
            .getLikeApellido("rez")
            .forEach(System.out::println);

        System.out.println("**************************************");    
        
        //empleados
        
        I_EmpleadoRepository empleadoRepository = new EmpleadoRepository(conn);
        Empleado empleado = new Empleado("Julio","Kempes","$29000",2);
        empleadoRepository.save(empleado);
        System.out.println(empleado);

        empleadoRepository.remove(empleadoRepository.getbyid_Empleado(2));

        empleado = empleadoRepository.getbyid_Empleado(4);
        if(empleado != null){
            empleado.setid_empleados(3);
            empleadoRepository.update(empleado);
        }

        System.out.println("**************************************");  
        empleadoRepository.getAll().forEach(System.out::println);
       
        System.out.println("**************************************");
        empleadoRepository
            .getLikeNombre("cio")
            .forEach(System.out::println);

        System.out.println("**************************************");
        empleadoRepository
            .getLikeApellido("rez")
            .forEach(System.out::println);
    
            System.out.println("**************************************");
            System.out.println("**************************************");

        //categorias

        I_CategoriaRepository categoriaRepository = new CategoriaRepository(conn);
        Categoria categoria = new Categoria(3,Dia.DIAX3, 300, Giga.GB3, Pack.p3);
        categoriaRepository.save(categoria);
        System.out.println(categoria);

        categoriaRepository.remove(categoriaRepository.getbyid_Categoria(4));

        categoria = categoriaRepository.getbyid_Categoria(3);
        if(categoria != null){
            categoria.setid_categorias(3);
            categoriaRepository.update(categoria);
        }

        System.out.println("**************************************");  
        categoriaRepository.getAll().forEach(System.out::println);
       
        System.out.println("**************************************");
        categoriaRepository
            .getPrecio(400)
            .forEach(System.out::println);

        System.out.println("**************************************");
        System.out.println("**************************************");

        //ventas

        I_VentaRepository ventaRepository = new VentaRepository(conn);
        Venta ventas = new Venta(1, "18/03/2022", 1, 1,2);
        ventaRepository.save(ventas);
        System.out.println(ventas);

        ventaRepository.remove(ventaRepository.getbyid_Venta(4));
        ventas = ventaRepository.getbyid_Venta(3);
        if(ventas != null){
            ventas.setid_ventas(1);
            ventaRepository.update(ventas);
        }

        System.out.println("**************************************");  
        ventaRepository.getAll().forEach(System.out::println);
       
        System.out.println("**************************************");
        ventaRepository
            .getbyVenta("10/05/2022")
            .forEach(System.out::println);

        System.out.println("**************************************");
        System.out.println("**************************************");
    }
}
