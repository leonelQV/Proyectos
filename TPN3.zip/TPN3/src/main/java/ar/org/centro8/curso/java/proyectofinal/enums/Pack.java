package ar.org.centro8.curso.java.proyectofinal.enums;

public enum Pack {
    p1,
    p2,
    p3,
    p4
}
