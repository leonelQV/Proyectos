package ar.org.centro8.curso.java.proyectofinal.test;

import java.sql.Connection;
import ar.org.centro8.curso.java.proyectofinal.connector.Connector;
import ar.org.centro8.curso.java.proyectofinal.entities.Cliente;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_ClienteRepository;
import ar.org.centro8.curso.java.proyectofinal.repositories.jdbc.ClienteRepository;

public class TestCliente {
    public static void main(String[] args) {
        Connection conn=Connector.getConnection();
        I_ClienteRepository clienteRepository=new ClienteRepository(conn);
        Cliente cliente=new Cliente("Mario","Torres","43921448",1);
        clienteRepository.save(cliente);
        System.out.println(cliente);

        clienteRepository.remove(clienteRepository.getbyid(3));

        cliente=clienteRepository.getbyid(3);
        if(cliente!=null && cliente.getid_clientes()!=0){
            cliente.setNombre("Luis");
            cliente.setApellido("Alvarez");
            clienteRepository.update(cliente);
        }

        System.out.println("**************************************");
        clienteRepository.getAll().forEach(System.out::println);

        System.out.println("**************************************");
        clienteRepository
            .getLikeNombre("is")
            .forEach(System.out::println);
        System.out.println("**************************************");
        clienteRepository
            .getLikeApellido("rez")
            .forEach(System.out::println);

        System.out.println("**************************************");    
        I_ClienteRepository clienteRepository2 = new ClienteRepository(conn);
        Cliente cliente2=new Cliente("maria","","26",1);
        clienteRepository.save(cliente);
        System.out.println(cliente);

        clienteRepository.remove(clienteRepository.getbyid(2));

        cliente=clienteRepository.getbyid(4);
        if(cliente!=null){
            cliente.setid_categorias(3);
            clienteRepository.update(cliente);
        }

        System.out.println("**************************************");  
        clienteRepository.getAll().forEach(System.out::println);
        System.out.println("**************************************"); 
        clienteRepository
            .getLikeNombre(clienteRepository.getbyid(1))
            .forEach(System.out::println);










    }
}
