package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Cliente;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_ClienteRepository;

public class ClienteRepository implements I_ClienteRepository{
        private Connection conn;

        @Override
        public List<Cliente> getAll() {
            List<Cliente> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from clientes")) {
            while (rs.next()) {
                list.add(new Cliente(
                    rs.getInt("id_cliente"),
                    rs.getString("nombre"),
                    rs.getString("apellido"),
                    rs.getString("dni"),
                    rs.getInt("id_categorias")
                ));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
        }

        @Override
        public void save(Cliente clientes) {
            if (clientes == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into clientes (Id_clientes,nombre,apellido,dni,Id_categorias) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, clientes.getId_clientes());
            ps.setString(2, clientes.getNombre());
            ps.setString(3, clientes.getApellido());
            ps.setString(4, clientes.getDni());
            ps.setInt(5, clientes.getId_categorias());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                clientes.setId_clientes((rs.getInt(1)));
        } catch (Exception e) {
            System.out.println(e);
        }
        }

        @Override
        public void remove(Cliente clientes) {         
        if (clientes == null)
        return;
    try (PreparedStatement ps = conn.prepareStatement(
            "delete from clientes where Id_clientes=?")) {
        ps.setInt(1, clientes.getId_clientes());
        ps.execute();
    } catch (Exception e) {
        System.out.println(e);
    }            
        }

        @Override
        public void update(Cliente clientes) {         
        if (clientes == null)
        return;
    try (PreparedStatement ps = conn.prepareStatement(
            "update clientes set nombre=?, apellido=?, dni=?, Id_categorias=? where Id_clientes=?")) {
        ps.setString(1, clientes.getNombre());
        ps.setString(2, clientes.getApellido());
        ps.setString(3, clientes.getDni());
        ps.setInt(4, clientes.getId_categorias());
        ps.setInt(5, clientes.getId_clientes());
        ps.execute();
    } catch (Exception e) {
        System.out.println(e);
    }

        }

        

        
}
