package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Categoria;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;

public interface I_EmpleadoRepository {

    void save(Empleado empleado);

    void remove(Empleado empleado);

    void update(Empleado empleado);

    List<Empleado> getAll();

    default Stream<Empleado> getStream() {
        return getAll().stream();
    }

    default Empleado getbyid_Empleado(int id_empleados) {
        return getAll()
                .stream()
                .filter(a -> a.getId_empleados() == id_empleados)
                .findAny()
                .orElse(new Empleado());
    }

    default List<Empleado> getLikeNombre(String nombre) {
        if (nombre == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getNombre() != null)
                .filter(a -> a
                        .getNombre()
                        .toLowerCase()
                        .contains(nombre.toLowerCase()))
                .toList();
    }

    default List<Empleado> getLikeApellido(String apellido) {
        if (apellido == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getApellido() != null)
                .filter(a -> a
                        .getApellido()
                        .toLowerCase()
                        .contains(apellido.toLowerCase()))
                .toList();
    }

    default List<Empleado> getsueldo(String sueldo) {
        if (sueldo == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getSueldo() != null)
                .filter(a -> a
                        .getSueldo()
                        .toLowerCase()
                        .contains(sueldo.toLowerCase()))
                .toList();
    }

    default List<Empleado> getByCategoria(Categoria categorias) {
        if (categorias == null)
            return new ArrayList<Empleado>();
        return getStream()
                .filter(a -> a.getId_categorias() == categorias.getId_categorias())
                .collect(Collectors.toList());
    }

    default List<Empleado> getBySucursal(Venta ventas) {
        if (ventas == null)
            return new ArrayList<Empleado>();
        return getStream()
                .filter(a -> a.getId_categorias() == ventas.getId_ventas())
                .collect(Collectors.toList());
    }
}