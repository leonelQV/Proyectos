package ar.org.centro8.curso.java.proyectofinal.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import ar.org.centro8.curso.java.proyectofinal.entities.Categoria;
import ar.org.centro8.curso.java.proyectofinal.entities.Cliente;
import ar.org.centro8.curso.java.proyectofinal.entities.Empleado;
import ar.org.centro8.curso.java.proyectofinal.entities.Venta;

public interface I_VentasRepository {

    void save(Venta ventas);

    void remove(Venta ventas);

    void update(Venta ventas);

    List<Venta> getAll();

    default Stream<Venta> getStream() {
        return getAll().stream();
    }

    default Venta getbyid_Venta(int id_ventas) {
        return getAll()
                .stream()
                .filter(a -> a.getId_ventas() == id_ventas)
                .findAny()
                .orElse(new Venta());
    }

    default List<Venta> getbyVenta(String fechas) {
        if (fechas == null)
            return new ArrayList();
        return getAll()
                .stream()
                .filter(a -> a.getFechas() != null)
                .filter(a -> a
                        .getFechas()
                        .toLowerCase()
                        .contains(fechas.toLowerCase()))
                .toList();
    }

    default List<Venta> getByCliente(Cliente clientes) {
        if (clientes == null)
            return new ArrayList<Venta>();
        return getStream()
                .filter(a -> a.getId_cliente() == clientes.getId_clientes())
                .collect(Collectors.toList());
    }

    default List<Venta> getByCategoria(Categoria categorias) {
        if (categorias == null)
            return new ArrayList<Venta>();
        return getStream()
                .filter(a -> a.getId_categorias() == categorias.getId_categorias())
                .collect(Collectors.toList());
    }

    default List<Venta> getBySucursal(Empleado empleados) {
        if (empleados == null)
            return new ArrayList<Venta>();
        return getStream()
                .filter(a -> a.getId_empleados() == empleados.getId_empleados())
                .collect(Collectors.toList());
    }

}
