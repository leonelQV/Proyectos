package ar.org.centro8.curso.java.proyectofinal.repositories.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.proyectofinal.entities.Venta;
import ar.org.centro8.curso.java.proyectofinal.repositories.interfaces.I_VentaRepository;

public class VentaRepository implements I_VentaRepository {
    private Connection conn;

    public VentaRepository(Connection conn) {
        this.conn = conn;
    }

    @Override
    public List<Venta> getAll() {
        List<Venta> list = new ArrayList();
        try (ResultSet rs = conn.createStatement().executeQuery(
                "select * from ventas")) {
            while (rs.next()) {
                list.add(new Venta(
                        rs.getInt("id_ventas"),
                        rs.getString("fecha"),
                        rs.getInt("id_categorias"),
                        rs.getInt("id_clientes"),
                        rs.getInt("id_empleados")));
            }
        } catch (Exception e) {
            System.out.println(e);
        }
        return list;
    }

    @Override
    public void save(Venta ventas) {
        if (ventas == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "insert into ventas (id_ventas,fechas,id_categorias,id_clientes,id_empleados) values (?,?,?,?,?)",
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, ventas.getid_ventas());
            ps.setString(2, ventas.getFechas());
            ps.setInt(3, ventas.getid_categorias());
            ps.setInt(4, ventas.getid_cliente());
            ps.setInt(5, ventas.getid_empleados());
            ps.execute();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next())
                ventas.setid_ventas((rs.getInt(1)));
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void remove(Venta ventas) {
        if (ventas == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "delete from ventas where id_ventas?")) {
            ps.setInt(1, ventas.getid_ventas());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

    @Override
    public void update(Venta ventas) {
        if (ventas == null)
            return;
        try (PreparedStatement ps = conn.prepareStatement(
                "update ventas set fechas=?, id_categorias=?, id_cliente=?, id_empleados=? where id_ventas=?")) {
            ps.setString(1, ventas.getFechas());
            ps.setInt(4, ventas.getid_categorias());
            ps.setInt(5, ventas.getid_cliente());
            ps.setInt(5, ventas.getid_empleados());
            ps.setInt(5, ventas.getid_ventas());
            ps.execute();
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
