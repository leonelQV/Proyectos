package ar.org.centro8.curso.java.proyectofinal.entities;

public class Empleado {
    private int id_empleados;
    private String nombre;
    private String apellido;
    private String sueldo;
    private int id_categorias;

    public Empleado() {
    }

    public Empleado(String nombre, String apellido, String sueldo, int id_categorias) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldo = sueldo;
        this.id_categorias = id_categorias;
    }

    public Empleado(int id_empleados, String nombre, String apellido, String sueldo, int id_categorias) {
        this.id_empleados = id_empleados;
        this.nombre = nombre;
        this.apellido = apellido;
        this.sueldo = sueldo;
        this.id_categorias = id_categorias;
    }

    public Empleado(int int1, String string, String string2, String string3, int int2, int int3) {
    }

    @Override
    public String toString() {
        return "Empleados [id_empleados=" + id_empleados + ", nombre=" + nombre + ", apellido=" + apellido + ", sueldo="
                + sueldo + ", id_categorias=" + id_categorias + "]";
    }

    public int getid_empleados() {
        return id_empleados;
    }

    public void setid_empleados(int id_empleados) {
        this.id_empleados = id_empleados;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getSueldo() {
        return sueldo;
    }

    public void setSueldo(String sueldo) {
        this.sueldo = sueldo;
    }

    public int getid_categorias() {
        return id_categorias;
    }

    public void setid_categorias(int id_categorias) {
        this.id_categorias = id_categorias;
    }

    public int getid_ventas() {
        return 0;
    }

}
