package ar.org.centro8.curso.java.test;

import java.nio.channels.NetworkChannel;
import java.rmi.server.RemoteObject;

import javax.print.attribute.SupportedValuesAttribute;
import javax.sound.sampled.SourceDataLine;

import ar.org.centro8.curso.java.entities.AutoClasico;
import ar.org.centro8.curso.java.entities.AutoNuevo;
import ar.org.centro8.curso.java.entities.Radio;

public class Vehiculo {
    public static void main(String[] args) {
        Vehiculo v1= new Vehiculo(color:"Negro", marca:"Peugeot", modelo: "x1", precio:87000.0);
        System.out.println(v1);
    }
        AutoClasico aC= new AutoClasico(color:"Rojo", marca:"Fiat", modelo: "x2", 967000.0);
        System.out.println(aC);

        AutoNuevo aN= new AutoNuevo(Gris, Clio, X2, 98765.0);
        System.out.println (aN);
        
        Radio rA=  new Radio (Panasonic);
        System.out.print (rA);
        
       
    }


